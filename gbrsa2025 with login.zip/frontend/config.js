window.CONFIG = {
  APPS_SCRIPT_URL: "https://script.google.com/macros/s/AKfycbyPFNdVkdZO5_Gu4TaeFTc1fbH1541HTXtOxyzQrYY90dcPKJ6KlswHB9ru_xZfE26EGg/exec",
  SHEET_ID: "1jJzY7YPWp2z--NoA9zjegzss4ZJXH4_eTuaePmHe0dg",
  DATA_SHEET_NAME: "Data",
  RESULT_SHEET_NAME: "Result"
};
// Login backend URL
const LOGIN_API_URL = "https://script.google.com/macros/s/AKfycbzq3LYbSAoFRjt8wIbomxwehCOdAdGo4eCkpHlhj_ncTm27tpQJyMhzQHRQTfhKQ6WJ/exec";
